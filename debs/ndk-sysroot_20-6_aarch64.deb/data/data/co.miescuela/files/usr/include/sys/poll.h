#pragma once

/**
 * @file sys/poll.h
 * @brief Historical synonym for `<poll.h>`.
 *
 * New code should use `<poll.h>` directly.
 */

#include <poll.h>
